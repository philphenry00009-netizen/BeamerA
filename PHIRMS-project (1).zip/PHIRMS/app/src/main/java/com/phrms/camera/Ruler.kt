package com.phrms.camera

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Describes what the ruler currently controls. Items are listed top to bottom; index 0 is the top tick.
 * Re-binding a different spec (ISO, shutter, FPS, WB, tint, zoom, focus, iris, EV ...) re-uses the same widget.
 */
class RulerSpec(
    val title: String,
    val count: Int,
    val start: Int,
    val label: (Int) -> String,
    val major: (Int) -> Boolean = { it % 5 == 0 },
    val onChange: (Int) -> Unit
)

/** Vertical ruler dial: fixed value box at the centre line, ticks scroll under it, drag/fling and snap to the nearest valid step. */
class VerticalRuler(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val stepPx = 15 * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var spec: RulerSpec? = null
    private var pos = 0f
    private var lastIdx = 0
    private var dragging = false
    private var lastY = 0f
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null
    private val cyan = 0xFF3CC8E8.toInt()

    fun bind(s: RulerSpec?) {
        anim?.cancel()
        spec = s
        visibility = if (s == null) GONE else VISIBLE
        if (s != null) { lastIdx = s.start.coerceIn(0, s.count - 1); pos = lastIdx.toFloat() }
        invalidate()
    }

    private fun move(delta: Float) {
        val s = spec ?: return
        pos = (pos + delta).coerceIn(0f, (s.count - 1).toFloat())
        val idx = pos.roundToInt()
        if (idx != lastIdx) { lastIdx = idx; performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); s.onChange(idx) }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val s = spec ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel(); dragging = true; lastY = e.y
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                move(-(e.y - lastY) / stepPx); lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle(); vt = null
                val target = (pos - vy * 0.15f / stepPx).roundToInt().coerceIn(0, s.count - 1)
                anim = ValueAnimator.ofFloat(pos, target.toFloat()).apply {
                    duration = (120 + abs(target - pos) * 12).toLong().coerceAtMost(450)
                    interpolator = DecelerateInterpolator()
                    addUpdateListener { move((it.animatedValue as Float) - pos) }
                    start()
                }
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val s = spec ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val cy = h / 2f
        p.style = Paint.Style.FILL; p.color = 0x99000000.toInt()
        cv.drawRoundRect(0f, 0f, w, h, 10 * d, 10 * d, p)
        p.color = 0xFF9AA0A6.toInt(); p.textSize = 10 * d; p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText(s.title, w - 8 * d - p.measureText(s.title), 16 * d, p)
        val tickX = w - 10 * d
        val first = floor(pos - cy / stepPx).toInt() - 1
        val last = floor(pos + cy / stepPx).toInt() + 1
        p.strokeWidth = 1.5f * d; p.textSize = 11 * d; p.typeface = Typeface.MONOSPACE
        for (i in first..last) {
            if (i < 0 || i >= s.count) continue
            val y = cy + (i - pos) * stepPx
            if (y < 24 * d || y > h - 4 * d) continue
            val a = (255 * (1f - 0.65f * abs(y - cy) / cy)).toInt().coerceIn(40, 255)
            p.color = Color.argb(a, 255, 255, 255)
            val major = s.major(i)
            val len = if (major) 16 * d else 8 * d
            cv.drawLine(tickX - len, y, tickX, y, p)
            if (major) { val t = s.label(i); cv.drawText(t, tickX - len - 6 * d - p.measureText(t), y + 4 * d, p) }
        }
        // value indicator box on the centre line
        p.color = cyan; p.strokeWidth = 2 * d
        cv.drawLine(54 * d, cy, tickX, cy, p)
        p.style = Paint.Style.FILL
        cv.drawRoundRect(4 * d, cy - 15 * d, 62 * d, cy + 15 * d, 6 * d, 6 * d, p)
        p.color = Color.BLACK; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 13 * d
        val t = s.label(lastIdx.coerceIn(0, s.count - 1))
        while (p.measureText(t) > 52 * d && p.textSize > 8 * d) p.textSize -= 0.5f * d
        cv.drawText(t, 33 * d - p.measureText(t) / 2, cy + 4.5f * d, p)
    }
}

package com.phrms.camera

import android.content.Context
import android.graphics.*
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Sizes itself to the largest rectangle of the given aspect that fits its parent. */
class AspectFrame(c: Context) : FrameLayout(c) {
    private var aw = 16
    private var ah = 9
    fun setAspect(w: Int, h: Int) { if (w != aw || h != ah) { aw = w; ah = h; requestLayout() } }
    override fun onMeasure(ws: Int, hs: Int) {
        val mw = MeasureSpec.getSize(ws)
        val mh = MeasureSpec.getSize(hs)
        var w = mw
        var h = (w.toLong() * ah / aw).toInt()
        if (h > mh) { h = mh; w = (h.toLong() * aw / ah).toInt() }
        super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
}

/** Monitoring overlay: guides, grid, level, RGB histogram, audio meters, zebra/peaking/false-colour layer, focus box. */
class OverlayView(c: Context) : View(c) {
    companion object { val GUIDES = listOf("OFF", "1.85:1", "2.35:1", "2.39:1", "2.40:1", "4:3", "9:16", "4:5", "1:1")
        val GUIDE_RATIO = floatArrayOf(0f, 1.85f, 2.35f, 2.39f, 2.40f, 4f / 3f, 9f / 16f, 0.8f, 1f) }
    var hudOn = true
    var showHist = true
    var showAudio = true
    var showLevel = false
    var grid = 0
    var cross = false
    var dot = false
    var guideIdx = 0
    var layerOn = false
    var layer: Bitmap? = null
    val histR = IntArray(64); val histG = IntArray(64); val histB = IntArray(64)
    @Volatile var clipHi = false
    @Volatile var clipLo = false
    @Volatile var audioL = 0f
    @Volatile var audioR = 0f
    var tilt = 0f
    var tapX = -1f; var tapY = -1f; var tapAt = 0L
    var lockText = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = Rect()
    private val d = c.resources.displayMetrics.density
    private val yel = 0xFFFFD60A.toInt()

    private fun meter(cv: Canvas, x: Float, y: Float, w: Float, h: Float, level: Float) {
        val db = 20f * log10(max(level, 1e-5f))
        val f = ((db + 50f) / 50f).coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.color = 0x99000000.toInt(); cv.drawRect(x, y, x + w, y + h, p)
        val seg = 40
        for (i in 0 until seg) {
            val t = (i + 1f) / seg
            if (t > f) break
            val dbSeg = -50f + 50f * t
            p.color = if (dbSeg > -6f) 0xFFE5392F.toInt() else if (dbSeg > -18f) 0xFFC9A227.toInt() else 0xFF2ECC40.toInt()
            cv.drawRect(x + 2 * d + i * (w - 4 * d) / seg, y + 2 * d, x + 2 * d + (i + 0.8f) * (w - 4 * d) / seg, y + h - 2 * d, p)
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (layerOn && hudOn) layer?.let { dst.set(0, 0, width, height); cv.drawBitmap(it, null, dst, null) }
        if (hudOn) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            p.color = 0x88FFFFFF.toInt()
            if (grid == 1) for (i in 1..2) { cv.drawLine(w * i / 3, 0f, w * i / 3, h, p); cv.drawLine(0f, h * i / 3, w, h * i / 3, p) }
            if (cross) { cv.drawLine(w / 2 - 14 * d, h / 2, w / 2 + 14 * d, h / 2, p); cv.drawLine(w / 2, h / 2 - 14 * d, w / 2, h / 2 + 14 * d, p) }
            if (dot) { p.style = Paint.Style.FILL; cv.drawCircle(w / 2, h / 2, 3 * d, p) }
            if (guideIdx > 0) {
                val r = GUIDE_RATIO[guideIdx]
                var gw = w; var gh = w / r
                if (gh > h) { gh = h; gw = h * r }
                val l = (w - gw) / 2; val t = (h - gh) / 2
                p.style = Paint.Style.FILL; p.color = 0xAA000000.toInt()
                cv.drawRect(0f, 0f, w, t, p); cv.drawRect(0f, h - t, w, h, p); cv.drawRect(0f, t, l, h - t, p); cv.drawRect(w - l, t, w, h - t, p)
                p.style = Paint.Style.STROKE; p.color = 0xCCFFFFFF.toInt(); cv.drawRect(l, t, l + gw, t + gh, p)
            }
            if (showLevel) {
                val cx = w / 2; val cy = h / 2
                val ok = abs(tilt) < 1.5f
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = if (ok) 0xFF30D158.toInt() else yel
                cv.save(); cv.rotate(-tilt, cx, cy)
                cv.drawLine(cx - 70 * d, cy, cx - 20 * d, cy, p); cv.drawLine(cx + 20 * d, cy, cx + 70 * d, cy, p)
                cv.restore()
                cv.drawLine(cx - 12 * d, cy, cx + 12 * d, cy, p)
            }
            if (showHist) {
                val bw = 150 * d; val bh = 64 * d
                val x0 = 12 * d; val y0 = h - bh - 12 * d
                p.style = Paint.Style.FILL; p.color = 0x99000000.toInt(); cv.drawRect(x0, y0, x0 + bw, y0 + bh, p)
                val mx = (max(max(histR.maxOrNull() ?: 1, histG.maxOrNull() ?: 1), histB.maxOrNull() ?: 1)).coerceAtLeast(1) * 1.05f
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d
                val cols = intArrayOf(0xCCFF453A.toInt(), 0xCC30D158.toInt(), 0xCC0A84FF.toInt())
                val hs = arrayOf(histR, histG, histB)
                for (k in 0 until 3) {
                    p.color = cols[k]
                    for (i in 1 until 64) cv.drawLine(x0 + (i - 1) * bw / 63, y0 + bh - bh * hs[k][i - 1] / mx, x0 + i * bw / 63, y0 + bh - bh * hs[k][i] / mx, p)
                }
                p.style = Paint.Style.FILL
                if (clipHi) { p.color = 0xFFFF453A.toInt(); cv.drawRect(x0 + bw - 5 * d, y0, x0 + bw, y0 + 5 * d, p) }
                if (clipLo) { p.color = 0xFF0A84FF.toInt(); cv.drawRect(x0, y0, x0 + 5 * d, y0 + 5 * d, p) }
            }
            if (showAudio) {
                val mw = 200 * d; val mh = 12 * d
                val x0 = w - mw - 12 * d; val y0 = h - 2 * mh - 20 * d
                meter(cv, x0, y0, mw, mh, audioL); meter(cv, x0, y0 + mh + 4 * d, mw, mh, audioR)
            }
            if (System.currentTimeMillis() - tapAt < 2500 && tapX >= 0) {
                val cx = tapX * w; val cy = tapY * h; val half = 34 * d
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = yel
                cv.drawRect(cx - half, cy - half, cx + half, cy + half, p)
                val t = 6 * d
                cv.drawLine(cx - half, cy, cx - half + t, cy, p); cv.drawLine(cx + half, cy, cx + half - t, cy, p)
                cv.drawLine(cx, cy - half, cx, cy - half + t, p); cv.drawLine(cx, cy + half, cx, cy + half - t, p)
            }
            if (lockText.isNotEmpty()) {
                p.style = Paint.Style.FILL; p.color = yel; p.textSize = 12 * d; p.typeface = Typeface.DEFAULT_BOLD
                cv.drawText(lockText, w / 2 - p.measureText(lockText) / 2, 24 * d, p)
            }
        }
    }
}

/** One shared analysis pass (RGB + luma) feeding histogram, zebra, focus peaking and false colour. */
class Analyzer(private val tv: TextureView, private val overlay: OverlayView) {
    companion object { const val W = 320; const val H = 180
        val PEAK = intArrayOf(0xFFFF3B30.toInt(), 0xFF30D158.toInt(), 0xFF0A84FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt()) }
    var zebra = false
    var zebraLevel = 95
    var peak = false
    var peakColor = 0
    var falseColor = false
    private val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val px = IntArray(W * H)
    private val luma = IntArray(W * H)
    private val outPx = IntArray(W * H)
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()

    init { overlay.layer = out }

    fun active() = zebra || peak || falseColor || overlay.showHist

    fun tick() {
        overlay.layerOn = zebra || peak || falseColor
        if (!overlay.hudOn || !active() || !tv.isAvailable) return
        if (!busy.compareAndSet(false, true)) return
        try { tv.getBitmap(bmp) } catch (e: Exception) { busy.set(false); return }
        exec.execute {
            try { process() } finally { busy.set(false) }
            overlay.postInvalidate()
        }
    }

    private fun fc(l: Int): Int {
        val pct = l * 100 / 255
        return when {
            pct < 2 -> 0xFF7B2CBF.toInt(); pct < 8 -> 0xFF1E5BFF.toInt(); pct in 40..48 -> 0xFF2ECC40.toInt()
            pct in 52..62 -> 0xFFFF7AB6.toInt(); pct in 92..97 -> 0xFFFFE600.toInt(); pct >= 98 -> 0xFFFF2D2D.toInt()
            else -> (0xFF shl 24) or (l shl 16) or (l shl 8) or l
        }
    }

    private fun process() {
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        overlay.histR.fill(0); overlay.histG.fill(0); overlay.histB.fill(0)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            luma[i] = (r * 54 + g * 183 + b * 19) shr 8
            overlay.histR[r shr 2]++; overlay.histG[g shr 2]++; overlay.histB[b shr 2]++
        }
        val lim = W * H / 100
        overlay.clipHi = overlay.histR[63] > lim || overlay.histG[63] > lim || overlay.histB[63] > lim
        overlay.clipLo = overlay.histR[0] > lim && overlay.histG[0] > lim && overlay.histB[0] > lim
        if (zebra || peak || falseColor) {
            val zt = zebraLevel * 255 / 100
            val pc = PEAK[peakColor.coerceIn(0, 4)]
            for (y in 0 until H) for (x in 0 until W) {
                val i = y * W + x
                var o = 0
                if (falseColor) o = fc(luma[i])
                else if (zebra && luma[i] >= zt && ((x + y) / 4) % 2 == 0) o = 0xCCFF3030.toInt()
                else if (peak && x < W - 1 && y < H - 1 && abs(luma[i] - luma[i + 1]) + abs(luma[i] - luma[i + W]) > 48) o = pc
                outPx[i] = o
            }
            out.setPixels(outPx, 0, W, 0, 0, W, H)
        }
    }
}

/** Input level meter (AudioRecord, stereo if the phone allows). Stopped while MediaRecorder owns the microphone. */
class AudioMeter(private val onLevel: (Float, Float) -> Unit) {
    @Volatile private var run = false
    private var thread: Thread? = null

    fun start() {
        if (run) return
        run = true
        thread = Thread {
            val rate = 48000
            var ch = AudioFormat.CHANNEL_IN_STEREO
            var min = AudioRecord.getMinBufferSize(rate, ch, AudioFormat.ENCODING_PCM_16BIT)
            var rec: AudioRecord? = null
            try { if (min > 0) rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, ch, AudioFormat.ENCODING_PCM_16BIT, min * 2) } catch (e: Exception) {}
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
                rec?.release(); rec = null
                ch = AudioFormat.CHANNEL_IN_MONO
                min = AudioRecord.getMinBufferSize(rate, ch, AudioFormat.ENCODING_PCM_16BIT)
                try { if (min > 0) rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, ch, AudioFormat.ENCODING_PCM_16BIT, min * 2) } catch (e: Exception) {}
            }
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) { rec?.release(); run = false; return@Thread }
            val stereo = ch == AudioFormat.CHANNEL_IN_STEREO
            val buf = ShortArray(2400)
            try {
                rec.startRecording()
                while (run) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    var pl = 0; var pr = 0
                    var i = 0
                    while (i < n) {
                        val a = abs(buf[i].toInt()); if (a > pl) pl = a
                        if (stereo && i + 1 < n) { val b = abs(buf[i + 1].toInt()); if (b > pr) pr = b }
                        i += if (stereo) 2 else 1
                    }
                    if (!stereo) pr = pl
                    onLevel(pl / 32768f, pr / 32768f)
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) {}
                rec.release(); run = false
            }
        }.also { it.start() }
    }

    fun stop() {
        run = false
        try { thread?.join(800) } catch (e: Exception) {}
        thread = null
    }
}
